create
    definer = root@localhost procedure udp_commit(IN username varchar(30), IN password varchar(30),
                                                  IN newMessage varchar(255), IN iss_id int)
BEGIN
		IF username NOT IN (SELECT u.username FROM users u) THEN
									SIGNAL SQLSTATE '45000'
                                    SET MESSAGE_TEXT = 'No such user!';
		ELSEIF password <> (SELECT u.password 
				FROM users u 
                WHERE u.username = username) THEN
									SIGNAL SQLSTATE '45000'
                                    SET MESSAGE_TEXT = 'Password is incorrect!';
		ELSEIF iss_id NOT IN (SELECT i.id FROM issues i) THEN
									SIGNAL SQLSTATE '45000'
                                    SET MESSAGE_TEXT = 'The issue does not exist!';
		ELSE
			INSERT INTO commits (message, issue_id, repository_id, contributor_id) 
			SELECT
				newMessage AS `message`,
                iss_id AS `issue_id`,
                (SELECT i.repository_id 
                FROM issues i
                WHERE i.id = iss_id) AS `repository_id`,
                (SELECT u.id) AS `contributor_id`
			FROM users u
            WHERE u.username = username;
			END IF;
		END;

