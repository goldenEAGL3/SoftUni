create
    definer = root@localhost procedure udp_findbyextension(IN extension varchar(20))
BEGIN
		SELECT f.id, f.name, CONCAT(f.size, 'KB') AS `size`
        FROM files f
        WHERE f.name LIKE CONCAT('%', extension)
        ORDER BY f.id;
    END;

