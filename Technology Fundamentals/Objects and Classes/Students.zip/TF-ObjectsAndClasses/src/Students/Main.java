package Students;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String command = sc.nextLine();
		
		List<Students> myStudents = new ArrayList<>();
	
		while(!"end".equals(command)) {
			
			String[] data = command.split("\\s+");
			
			String firstName = data[0];
			String lastName = data[1];
			int age = Integer.parseInt(data[2]);
			String hometown = data[3];
			
			Students newStudent = new Students();
			
			newStudent.setFirstName(firstName);
			newStudent.setLastName(lastName);
			newStudent.setAge(age);
			newStudent.setHometown(hometown);
			
			myStudents.add(newStudent);
			command = sc.nextLine();
		}
		
		String inputTown = sc.nextLine();
		
		for(Students elem : myStudents  ) {
			if(inputTown.equals(elem.getHometown())) {
				System.out.printf("%s %s is %d years old%n", elem.getFirstName(), elem.getLastName(), elem.getAge());
			}
			
		}

	}

}
